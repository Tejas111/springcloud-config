package com.myapp.spring.security;

import lombok.*;

@Data
@AllArgsConstructor
@Getter
@Setter
public class LoginBean {

    private String username,password;
}
