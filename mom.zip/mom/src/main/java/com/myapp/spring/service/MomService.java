package com.myapp.spring.service;

import com.myapp.spring.model.MomModel;

import java.util.List;

public interface MomService {
    List<MomModel> getlast5();
}
