package com.myapp.spring.security;

import org.springframework.stereotype.Component;

@Component
public class LoginManagerBean {

    private static ThreadLocal<LoginBean> threadLocal
            = new ThreadLocal<>();

    public void login(String username,String password){
        LoginBean loginBean =threadLocal.get();
        if(loginBean ==null){
            loginBean = new LoginBean(username,password);
            threadLocal.set(loginBean);
        }

    }
    public LoginBean getLoggedInUser(){
        return threadLocal.get();
    }

    public void logout(){
        threadLocal.remove();
    }


}
