package com.myapp.spring;


import com.myapp.spring.model.Flight;
import com.myapp.spring.service.FlightService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.Arrays;
import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.doReturn;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class FlightControllerTest {

    @MockBean
    private FlightService flightService;

    @Autowired
    private MockMvc mockMvc;

    @Test
    @DisplayName("All feedback found - GET /flights/sourceCity/destinationCity")
    public void testAllFlightFound() throws Exception {
        Flight firstFlight = new Flight(16, "Delhi", "Bengaluru", 8756.5, 3.5);


        doReturn(Arrays.asList(firstFlight)).when(flightService).find("delhi","Bengaluru");

        mockMvc.perform(MockMvcRequestBuilders.get("/flights/delhi/Bengaluru", 2))

                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(jsonPath("$[0].id", is(16)))
        .andExpect(jsonPath("$[0].sourceCity", is("Delhi")));

    }
}
