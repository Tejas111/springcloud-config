INSERT INTO mom (mom_id,meeting_id,dates,times) VALUES (1,'3a33','2020-05-16','19:30:10');
INSERT INTO mom (mom_id,meeting_id,dates,times) VALUES (2,'3a34','2020-05-16','19:30:10');
INSERT INTO mom (mom_id,meeting_id,dates,times) VALUES (3,'3a35','2020-05-16','19:30:10');
INSERT INTO mom (mom_id,meeting_id,dates,times) VALUES (4,'3a36','2020-05-16','19:30:10');
INSERT INTO mom (mom_id,meeting_id,dates,times) VALUES (5,'3a37','2020-05-16','19:30:10');