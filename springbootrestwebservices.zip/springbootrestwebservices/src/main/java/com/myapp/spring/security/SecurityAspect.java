package com.myapp.spring.security;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class SecurityAspect {

    @Autowired
    private LoginManagerBean loginManagerBean;

//    @Before(value = "execution((* com.myapp.spring.dao.*.*(..)) & (* com.myapp.spring.dao.*.*(..)) ")

    //@Before(value="bean(*DAOImpl) && bean(*ServiceImpl)")
    //@Before(value = "within(com.myapp.spring.dao.* || com.myapp.spring.service.*)")
    public void authenticate(){
        if(loginManagerBean.getLoggedInUser() == null){
            throw new SecurityException("U Must Login To Access");
        }

        else {
            if(loginManagerBean.getLoggedInUser().getUsername().equals("admin")) {
                System.out.println("Welcome User "+loginManagerBean.getLoggedInUser().getUsername());

            }
            else
                throw new SecurityException("Invalid Username");
        }


    }


}
