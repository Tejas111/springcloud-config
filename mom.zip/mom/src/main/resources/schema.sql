DROP TABLE IF EXISTS mom;

CREATE TABLE mom(
    mom_id INT NOT NULL,
    meeting_id VARCHAR(50) NOT NULL PRIMARY KEY,
    dates DATE NOT NULL,
    times TIME NOT NULL
);