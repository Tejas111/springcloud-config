package com.myapp.spring.service;

import com.myapp.spring.model.Flight;

import java.util.List;

public interface FlightService {

    List<Flight> getAll();
    Flight saveNewFlight(Flight flight);
    List<Flight> find(String sourceCity,String destinationCity);

}
