package com.myapp.spring.service;

import com.myapp.spring.model.MomModel;
import com.myapp.spring.repository.MomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MomServiceImpl implements MomService {

    @Autowired
    private MomRepository mom;

    public List<MomModel> getlast5(){
        return mom.findAll();
    }
}
