package com.myapp.spring.service;

import com.myapp.spring.model.Flight;

import com.myapp.spring.repository.FlightRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FlightServiceImpl implements  FlightService {

    @Autowired
    private FlightRepository flightRepository;


    @Override
    public List<Flight> getAll() {
        return flightRepository.findAll();
    }

    @Override
    public Flight saveNewFlight(Flight flight) {
        return flightRepository.save(flight);
    }

    @Override
    public List<Flight> find(String sourceCity, String destinationCity) {
        return flightRepository.findBySourceCityAndDestinationCity(sourceCity,destinationCity);
    }
}
