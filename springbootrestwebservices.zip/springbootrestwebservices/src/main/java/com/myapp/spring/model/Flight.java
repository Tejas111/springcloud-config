package com.myapp.spring.model;

import lombok.*;

import javax.persistence.*;


@NoArgsConstructor
@AllArgsConstructor()
@Getter
@Setter
@EqualsAndHashCode
@ToString
@Entity
@Table(name="restflights")
public class Flight {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="FLIGHT_ID")
    private int id;

    @Column(name="FLIGHT_SOURCE_CITY")
    private String sourceCity;
    @Column(name="FLIGHT_DESTINATION_CITY")
    private String destinationCity;
    @Column(name="FLIGHT_FARE")
    private double price;
    @Column(name="FLIGHT_DURATION")
    private double duration;





}
