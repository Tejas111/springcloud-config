package com.myapp.spring.rest.api;

import com.myapp.spring.model.MomModel;
import com.myapp.spring.service.MomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class MomController {

    @Autowired
    private MomService mom;

    @GetMapping("/moms")
    public ResponseEntity<List<MomModel>> getlast(){

        return new ResponseEntity<>(mom.getlast5(), HttpStatus.OK);
    }
}
