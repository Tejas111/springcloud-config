package com.myapp.spring.model;
import lombok.*;
import org.hibernate.type.descriptor.sql.VarcharTypeDescriptor;

import javax.persistence.*;
import java.sql.Date;
import java.sql.Time;


@NoArgsConstructor
@AllArgsConstructor()
@Getter
@Setter
@EqualsAndHashCode
@ToString
@Entity
@Table(name="mom")
public class MomModel {
    private int mom_id;
    @Id
    private String meeting_id;
    private Date dates;
    private Time  times;
}
