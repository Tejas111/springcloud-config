package com.myapp.spring.rest.api;

import com.myapp.spring.model.Flight;
import com.myapp.spring.service.FlightNotFoundException;
import com.myapp.spring.service.FlightService;

//import org.jboss.logging.Logger;
//import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;



import java.util.List;

// Spring Bean and expose the resources as services using Unique Url
@RestController
public class FlightController {

    //injecting the dependency of the class
    @Autowired
    private FlightService flightService;

//    Logger logger = LoggerFactory.getLogger(FlightController.class);

//    private static final Logger LOG = Logger.getLogger(FlightController.class.getName());

    // Rest Web Service Resource map the resource to GET type of Request
    // a resource should be mapped to a URI
    // http://localhost:8888/flights


    @GetMapping("/flights")
    public ResponseEntity<List<Flight>> findAll(){

        return new ResponseEntity<>(flightService.getAll(), HttpStatus.OK);

    }
    @PostMapping("/flights")
    public ResponseEntity<Flight> addFlight(@RequestBody Flight flight){
        return new ResponseEntity<>(flightService.saveNewFlight(flight),
                HttpStatus.CREATED);

    }

    // http://localhost:8888/flights/bengaluru/delhi
    @GetMapping("/flights/{sourceCity}/{destinationCity}")
    public ResponseEntity<List<Flight>> search(
            @PathVariable("sourceCity") String sourceCity,
            @PathVariable("destinationCity") String destinationCity) throws FlightNotFoundException {

        List<Flight> list=flightService.find(sourceCity,destinationCity);

//        LOG.log(Logger.Level.INFO, "/flights - &gt; " + list);

        if(list.isEmpty()){
//            logger.debug("flights not found:{}",list);
    throw new FlightNotFoundException("No Matching Flights For "+sourceCity+ " "+destinationCity);
        }
//        logger.info("flights found: {}",list);
        return new ResponseEntity<>(list,
                HttpStatus.OK);

    }
}

// Step 1
 // Spring Boot Loads EnvironmentData (application.properties)
// DataSource
// EntityManagerFactory( Injected With The DataSource)
// Manage Transactions
// JpaTransactionManager( Injected With EntityManagerFactory)



// flight{id,sourceCity,destinationCity,price,duration}

//{
    //   "id":1
//  "sourceCity":"Bengaluru"
//  "destinationCity":"Bengaluru"
//  "price":56788.5
//  "duration":2.2
        //}

// JSON Types
//  JSONObject {"":}
// JSONString ""
// JSONNumber
// JSONArray []
// JSONBoolean
