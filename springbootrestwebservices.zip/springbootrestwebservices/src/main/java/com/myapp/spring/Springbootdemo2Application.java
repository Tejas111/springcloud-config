package com.myapp.spring;

import com.myapp.spring.security.LoginManagerBean;
import com.myapp.spring.service.FlightService;
import org.springframework.aop.support.AopUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springbootdemo2Application implements CommandLineRunner {

    @Autowired
    private FlightService flightService;

    @Autowired
    private LoginManagerBean loginManagerBean;

    public static void main(String[] args) {

        SpringApplication.run(Springbootdemo2Application.class, args);
    }

    @Override
    public void run(String... args) throws Exception {

        System.out.println("Proxy "+ AopUtils.isAopProxy(flightService));
        loginManagerBean.login("admin","");
        flightService.getAll().forEach(System.out::println);
    }
}
