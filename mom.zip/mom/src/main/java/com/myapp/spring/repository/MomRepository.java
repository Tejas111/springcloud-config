package com.myapp.spring.repository;

import com.myapp.spring.model.MomModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MomRepository extends JpaRepository<MomModel,Integer> {
    @Query(value = "SELECT * FROM mom ORDER BY dates LIMIT 3",nativeQuery = true)
    List<MomModel> findAll();
}
